# Production deployment checklist
1. Push this source to a private Git repository.
2. Create managed PostgreSQL and set `DATABASE_URL`.
3. Add all server environment variables in the hosting dashboard.
4. Build and run database migrations as a controlled deployment step.
5. Seed the initial admin only after setting a strong secret.
6. Configure private object storage and implement signed download route before accepting paid PDF orders.
7. Configure Razorpay webhook and verify in test mode first.
8. Set the actual Half-Yearly and Board Exam dates in the admin settings.
9. Enable uptime monitoring, logs, alerts, backup retention and restore testing.
10. Deploy to a paid/always-on plan if 24/7 availability is required. Free tiers may sleep.

## Enable mobile OTP sign-in
1. Create a Twilio Messaging Service and attach an SMS-capable sender (or use a permitted `TWILIO_FROM_NUMBER`).
2. Add `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, `TWILIO_MESSAGING_SERVICE_SID` (or `TWILIO_FROM_NUMBER`), `OTP_HASH_SECRET`, and the exact HTTPS `APP_URL` as server-side environment variables.
3. Apply the Prisma schema before deploying the OTP route; it includes the `OtpChallenge` table.
4. Deploy to HTTPS and test with a permitted phone number before public launch.
5. Android Chrome WebOTP may auto-fill because the SMS ends with the origin-bound line for `APP_URL`; browser/OS support and exact domain matching are required. Otherwise, manual code entry remains available.
6. Set Twilio spending alerts and messaging limits, and review local/provider rate limits before public launch.
