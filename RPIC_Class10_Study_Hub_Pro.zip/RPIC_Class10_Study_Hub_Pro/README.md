# RPIC SCHOOL — Class 10 Study Hub Pro

A multi-file Next.js application scaffold for UP Board Class 10, Session 2026–27. This is not a single HTML file. It includes a premium responsive UI, API routes, PostgreSQL/Prisma data model, session-based authentication, AI chat integration, Razorpay order/signature/webhook routes, PDF request flow, admin overview, PWA shell and environment configuration.

## Important status
- The UI is implemented and interactive.
- Database-backed authentication, PDF requests, AI chat, payment routes and admin overview are implemented as server routes.
- Production use requires a real PostgreSQL database, HTTPS hosting, secure environment variables, private object storage, an admin account, uploaded/approved question content, Razorpay setup and an AI provider key.
- SMS OTP is deliberately not faked; the current login route uses email/password.
- The public app does not claim payment success until the server verifies a signature or webhook.
- The PDF Store UI is not a complete file-serving pipeline yet: connect private S3-compatible storage and a signed/authenticated download route before selling real PDFs.
- Certificate/report template previews use the exact reference URLs provided. Personalized PDF rendering/QR verification needs a document-rendering and QR service to be configured.
- The countdown default is only a UI example and should be set to the official date/time in Admin before students rely on it.
- This project is not deployed; no 24/7 uptime is claimed.

## Requirements
- Node.js 20+
- PostgreSQL
- npm

## Local setup
1. Copy `.env.example` to `.env.local`.
2. Set `DATABASE_URL`, a random `AUTH_SECRET` (32+ characters), and a strong initial admin password.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Generate Prisma client and migrate:
   ```bash
   npm run db:generate
   npm run db:migrate
   npm run db:seed
   ```
5. Start:
   ```bash
   npm run dev
   ```
6. Open `http://localhost:3000`.

## Admin bootstrap
Set `INITIAL_ADMIN_EMAIL` and a strong `INITIAL_ADMIN_PASSWORD` in `.env.local` before running `npm run db:seed`. Never deploy the example password. After first setup, rotate credentials and protect environment access.

## AI Assistant
Set `OPENAI_API_KEY` server-side and optionally `OPENAI_MODEL`. The UI shows a clear configuration error when no key is present. Do not put provider secrets in `NEXT_PUBLIC_*` variables.

## Razorpay
Configure `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, `RAZORPAY_WEBHOOK_SECRET`. Set Razorpay webhook URL to:
`https://YOUR_DOMAIN/api/payments/webhook`
Enable captured/paid events in Razorpay. The frontend must still be wired to the Razorpay Checkout JS for order checkout and must call `/api/payments/verify` after checkout returns; server signature verification is implemented.

## Before public launch
- Configure managed Postgres backups and private object storage.
- Implement secure PDF upload/download and signed URLs; never expose private originals in `/public`.
- Wire real Razorpay Checkout to `/api/payments/create-order` and `/api/payments/verify`.
- Add SMS OTP provider only if OTP login is needed.
- Add test-question authoring/import and result/report PDF generation.
- Implement CSRF/origin protections appropriate to deployment, rate limiting, email verification, privacy notice and retention policy.
- Configure monitoring, alerts, uptime checks and automatic restarts on production hosting.
- Run `npm run build` and test all flows on a staging deployment.

## Mobile OTP login (real SMS, not demo OTP)

The sign-in screen uses the student's name and Indian mobile number. `Send OTP` creates a cryptographically random six-digit code, sends it through Twilio SMS, stores only a keyed hash in PostgreSQL, and expires it after five minutes. A resend is rate-limited and the next code is guaranteed not to match the immediately previous code. `Login` verifies the code server-side, limits failed attempts, and creates the session.

Set these server-only variables in `.env.local` / your hosting provider:

```env
TWILIO_ACCOUNT_SID="AC..."
TWILIO_AUTH_TOKEN="..."
TWILIO_MESSAGING_SERVICE_SID="MG..."
# Or use a Twilio sender number instead of a Messaging Service:
TWILIO_FROM_NUMBER="+1..."
OTP_HASH_SECRET="a-different-random-secret-at-least-32-characters"
```

Create a Twilio Messaging Service in the Twilio Console and attach an SMS-capable sender, or configure a permitted Twilio sender number. Apply the database schema before testing (`npx prisma db push` for a new development database). Do not expose these credentials with a `NEXT_PUBLIC_` prefix. Real SMS delivery may incur provider charges and requires a correctly configured account and destination permissions.

**Chrome OTP auto-fill:** the page requests the browser WebOTP API and uses the `one-time-code` autocomplete hint. Automatic reading is browser/OS/SMS-template dependent; for Android Chrome, the app sends an origin-bound final SMS line (`@your-domain #123456`) based on `APP_URL`; `APP_URL` must exactly match the deployed HTTPS origin. If the provider's message template does not support that format, students can still type the real SMS code manually. The app never displays or invents the OTP itself.

For local development, open the running app URL in Chrome (normally `http://localhost:3000`). For access from other phones, deploy the app to HTTPS first; production WebOTP requires a secure context and an SMS format that matches the deployed domain.
