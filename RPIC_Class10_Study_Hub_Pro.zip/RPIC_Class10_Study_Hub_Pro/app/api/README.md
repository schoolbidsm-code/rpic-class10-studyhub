# API route map
- POST /api/auth/login — password-based session login
- POST /api/auth/logout — closes current session
- GET/POST /api/requests — own PDF requests
- POST /api/ai/chat — AI tutoring (OPENAI_API_KEY required)
- POST /api/payments/create-order — creates Razorpay order for active product
- POST /api/payments/verify — validates Razorpay signature and grants purchase
- POST /api/payments/webhook — validates webhook signature and confirms payment
- GET /api/admin/overview — admin-only metrics
- GET /api/health — real DB/provider configuration status
