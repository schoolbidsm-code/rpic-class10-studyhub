import { NextResponse } from "next/server";
import { requireAdmin } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { safeError } from "@/lib/http";
export async function GET(){try{await requireAdmin();const [students,requests,payments,orders,certificates]=await Promise.all([
 prisma.user.count({where:{role:"STUDENT"}}),prisma.pdfRequest.count({where:{status:{in:["REQUESTED","UNDER_REVIEW"]}}}),
 prisma.payment.count({where:{status:"PAID"}}),prisma.idCardOrder.count(),prisma.certificate.count()
]);return NextResponse.json({students,pendingRequests:requests,verifiedPayments:payments,idCardOrders:orders,certificates});}catch(e){return safeError(e);}}