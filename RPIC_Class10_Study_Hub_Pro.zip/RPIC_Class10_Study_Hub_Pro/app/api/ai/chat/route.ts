import { NextRequest, NextResponse } from "next/server";
import OpenAI from "openai";
import { z } from "zod";
import { getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { safeError } from "@/lib/http";
const schema=z.object({message:z.string().min(1).max(8000)});
export async function POST(req:NextRequest){
 try{
  const user=await getCurrentUser();
  if(!process.env.OPENAI_API_KEY) return NextResponse.json({error:"AI service is not configured. Add OPENAI_API_KEY on the server."},{status:503});
  const {message}=schema.parse(await req.json());
  const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
  const completion=await client.chat.completions.create({
   model:process.env.OPENAI_MODEL||"gpt-4.1-mini",
   messages:[
    {role:"system",content:"You are Ask RPIC AI, a careful educational tutor. Explain clearly in the user's language (Hindi, English, or Hinglish). Prefer step-by-step teaching appropriate to Class 10 when relevant. Never invent official marks, school announcements, exam dates, or sources. State uncertainty when needed. Do not claim to have seen private files unless they are provided in this request."},
    {role:"user",content:message}
   ],
   max_tokens:1200
  });
  const answer=completion.choices[0]?.message?.content?.trim()||"I couldn't generate an answer. Please try again.";
  if(user){await prisma.aiMessage.createMany({data:[{userId:user.id,role:"user",content:message},{userId:user.id,role:"assistant",content:answer}]});}
  return NextResponse.json({answer});
 }catch(e){return safeError(e);}
}