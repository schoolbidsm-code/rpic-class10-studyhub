import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { createSession, requestMeta } from "@/lib/auth";
import { safeError } from "@/lib/http";
const schema=z.object({email:z.string().email(),password:z.string().min(1).max(200)});
export async function POST(req:NextRequest){
 try{
  const body=schema.parse(await req.json());
  const user=await prisma.user.findUnique({where:{email:body.email}});
  if(!user?.passwordHash || !(await bcrypt.compare(body.password,user.passwordHash))) return NextResponse.json({error:"Invalid email or password."},{status:401});
  await createSession(user.id);
  const meta=await requestMeta();
  await prisma.loginSession.create({data:{userId:user.id,userAgent:meta.userAgent,ipHash:meta.ip==="unknown"?null:await hashIp(meta.ip)}});
  await prisma.auditLog.create({data:{actorId:user.id,action:"LOGIN",targetType:"User",targetId:user.id}});
  return NextResponse.json({user:{id:user.id,name:user.name,role:user.role}});
 }catch(e){return safeError(e);}
}
async function hashIp(ip:string){const {createHash}=await import("node:crypto");return createHash("sha256").update(ip+process.env.AUTH_SECRET).digest("hex");}