import { NextResponse } from "next/server";
import { clearSession, getCurrentUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
export async function POST(){
 const user=await getCurrentUser();
 if(user){await prisma.loginSession.updateMany({where:{userId:user.id,endedAt:null},data:{endedAt:new Date()}});await prisma.auditLog.create({data:{actorId:user.id,action:"LOGOUT",targetType:"User",targetId:user.id}});}
 await clearSession();
 return NextResponse.json({ok:true});
}