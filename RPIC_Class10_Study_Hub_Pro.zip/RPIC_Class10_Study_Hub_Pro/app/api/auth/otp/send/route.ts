import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { normalizeIndianMobile } from "@/lib/phone";
import { generateOtp, hashOtp, webOtpDomain } from "@/lib/otp";
import { isTwilioSmsConfigured, sendTwilioSms } from "@/lib/twilio-sms";

const schema = z.object({ name: z.string().trim().min(2).max(80), mobile: z.string().min(10).max(16) });
export async function POST(req: NextRequest) {
  try {
    const body = schema.parse(await req.json());
    const mobile = normalizeIndianMobile(body.mobile);
    if (!isTwilioSmsConfigured()) {
      return NextResponse.json({ error: "Real SMS OTP is not configured yet. Add Twilio SMS credentials on the server." }, { status: 503 });
    }
    const recent = await prisma.otpChallenge.findFirst({ where: { mobile }, orderBy: { createdAt: "desc" } });
    if (recent && Date.now() - recent.createdAt.getTime() < 45_000) {
      return NextResponse.json({ error: "Please wait 45 seconds before requesting another OTP." }, { status: 429 });
    }
    const code = generateOtp(recent?.codeHash, mobile);
    const domain = webOtpDomain();
    const message = `Your RPIC SCHOOL Class 10 Study Hub OTP is ${code}. It expires in 5 minutes. Do not share this code.\n\n@${domain} #${code}`;
    await sendTwilioSms(mobile, message);
    await prisma.otpChallenge.create({ data: { mobile, codeHash: hashOtp(mobile, code), expiresAt: new Date(Date.now() + 5 * 60_000) } });
    return NextResponse.json({ ok: true, mobile, message: "OTP sent by SMS. Android Chrome may auto-fill it when WebOTP is supported." });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not send OTP.";
    const status = /valid 10-digit|Invalid input/i.test(message) ? 400 : /not configured|APP_URL|AUTH_SECRET|OTP_HASH_SECRET/i.test(message) ? 503 : 502;
    console.error("OTP send failed:", message);
    return NextResponse.json({ error: status === 502 ? "Could not send SMS. Check the Twilio account, sender and destination permissions." : message }, { status });
  }
}
