import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { createSession, requestMeta } from "@/lib/auth";
import { normalizeIndianMobile } from "@/lib/phone";
import { otpMatches } from "@/lib/otp";

const schema = z.object({ name: z.string().trim().min(2).max(80), mobile: z.string().min(10).max(16), code: z.string().regex(/^\d{6}$/) });
export async function POST(req: NextRequest) {
  try {
    const body = schema.parse(await req.json());
    const mobile = normalizeIndianMobile(body.mobile);
    const challenge = await prisma.otpChallenge.findFirst({ where: { mobile, consumedAt: null }, orderBy: { createdAt: "desc" } });
    if (!challenge || challenge.expiresAt.getTime() <= Date.now() || challenge.attempts >= 5) {
      return NextResponse.json({ error: "OTP has expired or reached its attempt limit. Send a new OTP." }, { status: 401 });
    }
    if (!otpMatches(mobile, body.code, challenge.codeHash)) {
      await prisma.otpChallenge.update({ where: { id: challenge.id }, data: { attempts: { increment: 1 } } });
      return NextResponse.json({ error: "OTP is incorrect. Check the SMS and try again." }, { status: 401 });
    }
    await prisma.otpChallenge.update({ where: { id: challenge.id }, data: { consumedAt: new Date() } });

    const existing = await prisma.user.findUnique({ where: { mobile } });
    const user = existing
      ? await prisma.user.update({ where: { id: existing.id }, data: { name: body.name } })
      : await prisma.user.create({ data: { name: body.name, mobile, role: "STUDENT", className: "10", session: "2026-27" } });
    await createSession(user.id);
    const meta = await requestMeta();
    await prisma.loginSession.create({ data: { userId: user.id, userAgent: meta.userAgent } });
    await prisma.auditLog.create({ data: { actorId: user.id, action: "OTP_LOGIN", targetType: "User", targetId: user.id } });
    return NextResponse.json({ ok: true, user: { id: user.id, name: user.name, role: user.role, mobile: user.mobile } });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Could not verify OTP.";
    if (/valid 10-digit|Invalid input/i.test(message)) return NextResponse.json({ error: message }, { status: 400 });
    if (/AUTH_SECRET|OTP_HASH_SECRET/.test(message)) return NextResponse.json({ error: "Server OTP security is not configured. Contact the site administrator." }, { status: 503 });
    console.error("OTP verification failed:", message);
    return NextResponse.json({ error: "Login service is unavailable. Try again shortly." }, { status: 500 });
  }
}
