import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
export async function GET(){
 let database="error";try{await prisma.$queryRaw`SELECT 1`;database="connected";}catch{}
 const ai=process.env.OPENAI_API_KEY?"configured":"not_configured";
 const razorpay=process.env.RAZORPAY_KEY_ID&&process.env.RAZORPAY_KEY_SECRET?"configured":"not_configured";
 return NextResponse.json({status:database==="connected"?"ok":"degraded",database,ai,razorpay,checkedAt:new Date().toISOString()},{status:database==="connected"?200:503});
}