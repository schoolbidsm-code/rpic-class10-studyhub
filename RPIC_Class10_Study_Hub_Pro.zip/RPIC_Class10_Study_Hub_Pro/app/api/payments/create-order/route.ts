import { NextRequest, NextResponse } from "next/server";
import Razorpay from "razorpay";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { safeError } from "@/lib/http";
const schema=z.object({productId:z.string().min(1)});
export async function POST(req:NextRequest){
 try{
  const user=await requireUser();const {productId}=schema.parse(await req.json());
  if(!process.env.RAZORPAY_KEY_ID||!process.env.RAZORPAY_KEY_SECRET) return NextResponse.json({error:"Razorpay is not configured."},{status:503});
  const product=await prisma.pdfProduct.findFirst({where:{id:productId,isActive:true}});
  if(!product)return NextResponse.json({error:"Product is unavailable."},{status:404});
  const receipt=`rpic_${Date.now()}_${user.id.slice(-5)}`;
  const payment=await prisma.payment.create({data:{userId:user.id,productId:product.id,productName:product.title,amountPaise:product.pricePaise,receipt,status:"CREATED"}});
  const razorpay=new Razorpay({key_id:process.env.RAZORPAY_KEY_ID,key_secret:process.env.RAZORPAY_KEY_SECRET});
  const order=await razorpay.orders.create({amount:product.pricePaise,currency:"INR",receipt,notes:{paymentRecordId:payment.id,userId:user.id,productId:product.id}});
  await prisma.payment.update({where:{id:payment.id},data:{razorpayOrderId:order.id,status:"PENDING"}});
  return NextResponse.json({orderId:order.id,amount:order.amount,currency:order.currency,keyId:process.env.RAZORPAY_KEY_ID,productName:product.title});
 }catch(e){return safeError(e);}
}