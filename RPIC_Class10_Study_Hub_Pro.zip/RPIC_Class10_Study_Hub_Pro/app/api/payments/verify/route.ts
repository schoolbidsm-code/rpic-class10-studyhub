import { NextRequest, NextResponse } from "next/server";
import { createHmac, timingSafeEqual } from "node:crypto";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { safeError } from "@/lib/http";
const schema=z.object({razorpay_order_id:z.string(),razorpay_payment_id:z.string(),razorpay_signature:z.string()});
export async function POST(req:NextRequest){
 try{
  const user=await requireUser();const body=schema.parse(await req.json());
  if(!process.env.RAZORPAY_KEY_SECRET)return NextResponse.json({error:"Razorpay is not configured."},{status:503});
  const expected=createHmac("sha256",process.env.RAZORPAY_KEY_SECRET).update(`${body.razorpay_order_id}|${body.razorpay_payment_id}`).digest();
  const supplied=Buffer.from(body.razorpay_signature,"hex");
  if(supplied.length!==expected.length||!timingSafeEqual(supplied,expected))return NextResponse.json({error:"Payment signature verification failed."},{status:400});
  const payment=await prisma.payment.findFirst({where:{razorpayOrderId:body.razorpay_order_id,userId:user.id}});
  if(!payment)return NextResponse.json({error:"Payment order not found for this account."},{status:404});
  await prisma.$transaction(async tx=>{
   await tx.payment.update({where:{id:payment.id},data:{razorpayPaymentId:body.razorpay_payment_id,status:"PAID"}});
   if(payment.productId) await tx.purchase.upsert({where:{userId_productId:{userId:user.id,productId:payment.productId}},update:{paymentId:payment.id},create:{userId:user.id,productId:payment.productId,paymentId:payment.id}});
   await tx.auditLog.create({data:{actorId:user.id,action:"PAYMENT_VERIFIED",targetType:"Payment",targetId:payment.id}});
  });
  return NextResponse.json({verified:true,status:"PAID",receipt:payment.receipt});
 }catch(e){return safeError(e);}
}