import { NextRequest, NextResponse } from "next/server";
import { createHmac, timingSafeEqual } from "node:crypto";
import { prisma } from "@/lib/prisma";
export async function POST(req:NextRequest){
 const secret=process.env.RAZORPAY_WEBHOOK_SECRET;
 if(!secret)return NextResponse.json({error:"Webhook is not configured."},{status:503});
 const raw=await req.text();const signature=req.headers.get("x-razorpay-signature")||"";
 const expected=createHmac("sha256",secret).update(raw).digest();
 let supplied:Buffer;try{supplied=Buffer.from(signature,"hex");}catch{return NextResponse.json({error:"Invalid signature."},{status:400});}
 if(supplied.length!==expected.length||!timingSafeEqual(supplied,expected))return NextResponse.json({error:"Invalid signature."},{status:400});
 const event=JSON.parse(raw);
 if(event.event==="payment.captured"||event.event==="order.paid"){
  const paymentEntity=event.payload?.payment?.entity;
  const orderId=paymentEntity?.order_id||event.payload?.order?.entity?.id;
  const paymentId=paymentEntity?.id;
  if(orderId&&paymentId){
   const p=await prisma.payment.findUnique({where:{razorpayOrderId:orderId}});
   if(p&&p.status!=="PAID"){
    await prisma.$transaction(async tx=>{
     await tx.payment.update({where:{id:p.id},data:{status:"PAID",razorpayPaymentId:paymentId}});
     if(p.productId)await tx.purchase.upsert({where:{userId_productId:{userId:p.userId,productId:p.productId}},update:{paymentId:p.id},create:{userId:p.userId,productId:p.productId,paymentId:p.id}});
     await tx.auditLog.create({data:{actorId:p.userId,action:"PAYMENT_WEBHOOK_CONFIRMED",targetType:"Payment",targetId:p.id}});
    });
   }
  }
 }
 return NextResponse.json({received:true});
}