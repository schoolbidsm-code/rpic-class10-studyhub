import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { requireUser } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { safeError } from "@/lib/http";
const schema=z.object({subjectName:z.string().min(2).max(80),message:z.string().min(3).max(2000)});
export async function GET(){try{const user=await requireUser();const rows=await prisma.pdfRequest.findMany({where:{userId:user.id},orderBy:{createdAt:"desc"}});return NextResponse.json({requests:rows});}catch(e){return safeError(e);}}
export async function POST(req:NextRequest){try{const user=await requireUser();const data=schema.parse(await req.json());const row=await prisma.pdfRequest.create({data:{userId:user.id,...data}});await prisma.auditLog.create({data:{actorId:user.id,action:"PDF_REQUEST_CREATED",targetType:"PdfRequest",targetId:row.id}});return NextResponse.json({id:row.id,status:row.status},{status:201});}catch(e){return safeError(e);}}