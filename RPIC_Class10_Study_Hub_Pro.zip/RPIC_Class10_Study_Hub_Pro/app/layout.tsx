import type { Metadata, Viewport } from "next";
import "./globals.css";
import PwaRegister from "@/components/PwaRegister";
export const metadata: Metadata = {
 title: "RPIC SCHOOL — Class 10 Study Hub",
 description: "UP Board Class 10 Exam Preparation • Session 2026–27 • Developed by Divyansh Singh",
 applicationName: "RPIC Class 10 Study Hub",
 manifest: "/manifest.webmanifest",
};
export const viewport: Viewport = { themeColor:"#101a43", width:"device-width", initialScale:1, maximumScale:1 };
export default function RootLayout({children}:{children:React.ReactNode}) {
 return <html lang="en"><body><PwaRegister />{children}</body></html>;
}