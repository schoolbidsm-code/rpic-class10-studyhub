# Reference assets
- School logo: https://i.postimg.cc/1X0Pbh6B/file-000000004ff88211a39fc3753a8377e4-(1).jpg
- Certificate template: https://i.postimg.cc/HLTsQtJz/file-0000000083c08211b7fbce613b545018.png
- Progress report template: https://i.postimg.cc/RZ500mv3/file-00000000e9fc8208baab832d0779cdd4.png

These references are loaded by URL in the UI. For production reliability, download the authorized assets into this directory and update references to local assets after confirming usage rights.