import { NextResponse } from "next/server";
export function jsonError(message: string, status=400) { return NextResponse.json({error:message},{status}); }
export function safeError(error: unknown) {
  if (error instanceof Error && error.message === "UNAUTHORIZED") return jsonError("Please sign in to continue.",401);
  if (error instanceof Error && error.message === "FORBIDDEN") return jsonError("You do not have permission for this action.",403);
  console.error(error);
  return jsonError("The request could not be completed. Check server configuration and try again.",500);
}