import { createHash, randomInt, timingSafeEqual } from "node:crypto";

function otpSecret() {
  const secret = process.env.OTP_HASH_SECRET || process.env.AUTH_SECRET;
  if (!secret || secret.length < 32) throw new Error("Set OTP_HASH_SECRET or AUTH_SECRET to at least 32 characters.");
  return secret;
}
export function hashOtp(mobile: string, code: string) {
  return createHash("sha256").update(`${otpSecret()}:${mobile}:${code}`).digest("hex");
}
export function otpMatches(mobile: string, code: string, expectedHash: string) {
  const actual = Buffer.from(hashOtp(mobile, code), "hex");
  const expected = Buffer.from(expectedHash, "hex");
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}
export function generateOtp(exceptHash?: string, mobile = "") {
  for (let i = 0; i < 20; i++) {
    const code = String(randomInt(0, 1_000_000)).padStart(6, "0");
    if (!exceptHash || hashOtp(mobile, code) !== exceptHash) return code;
  }
  throw new Error("Could not generate a fresh OTP. Please retry.");
}
export function webOtpDomain() {
  const appUrl = process.env.APP_URL;
  if (!appUrl) throw new Error("Set APP_URL to the deployed HTTPS website origin for OTP delivery.");
  const url = new URL(appUrl);
  return url.host;
}
