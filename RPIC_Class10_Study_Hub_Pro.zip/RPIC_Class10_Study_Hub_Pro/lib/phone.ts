/** Normalize Indian mobile numbers to E.164 for SMS verification. */
export function normalizeIndianMobile(input: string): string {
  const raw = input.trim().replace(/[\s()-]/g, "");
  if (/^\+91[6-9]\d{9}$/.test(raw)) return raw;
  if (/^91[6-9]\d{9}$/.test(raw)) return `+${raw}`;
  if (/^[6-9]\d{9}$/.test(raw)) return `+91${raw}`;
  throw new Error("Enter a valid 10-digit Indian mobile number.");
}
