export const subjects = [
 {name:"Hindi",icon:"BookOpen",description:"Literature, grammar & writing"},
 {name:"English",icon:"Languages",description:"Reading, writing, grammar & literature"},
 {name:"Mathematics",icon:"Calculator",description:"Concepts, formulas & practice"},
 {name:"Science",icon:"Atom",description:"Physics, Chemistry & Biology"},
 {name:"Social Science",icon:"Globe2",description:"History, Geography, Civics & Economics"},
 {name:"Computer",icon:"Monitor",description:"Computer science & IT"}
];
export const scienceUnits = ["Physics","Chemistry","Biology"];
export const sstUnits = ["History","Geography","Civics","Economics"];