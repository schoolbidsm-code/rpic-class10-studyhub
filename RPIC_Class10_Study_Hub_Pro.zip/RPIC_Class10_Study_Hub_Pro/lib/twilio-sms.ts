export function isTwilioSmsConfigured() {
  return Boolean(process.env.TWILIO_ACCOUNT_SID && process.env.TWILIO_AUTH_TOKEN && (process.env.TWILIO_MESSAGING_SERVICE_SID || process.env.TWILIO_FROM_NUMBER));
}

export async function sendTwilioSms(to: string, bodyText: string) {
  const sid = process.env.TWILIO_ACCOUNT_SID;
  const token = process.env.TWILIO_AUTH_TOKEN;
  const serviceSid = process.env.TWILIO_MESSAGING_SERVICE_SID;
  const from = process.env.TWILIO_FROM_NUMBER;
  if (!sid || !token || (!serviceSid && !from)) throw new Error("SMS OTP is not configured. Add Twilio SMS credentials on the server first.");
  const body = new URLSearchParams({ To: to, Body: bodyText });
  if (serviceSid) body.set("MessagingServiceSid", serviceSid);
  else body.set("From", from!);
  const response = await fetch(`https://api.twilio.com/2010-04-01/Accounts/${sid}/Messages.json`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${Buffer.from(`${sid}:${token}`).toString("base64")}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body,
    cache: "no-store",
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = typeof data?.message === "string" ? data.message : "SMS provider could not send the OTP.";
    throw new Error(message);
  }
  return { sid: String(data.sid ?? "") };
}
