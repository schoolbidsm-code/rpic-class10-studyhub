const accountSid = () => process.env.TWILIO_ACCOUNT_SID;
const authToken = () => process.env.TWILIO_AUTH_TOKEN;
const serviceSid = () => process.env.TWILIO_VERIFY_SERVICE_SID;

export function isTwilioVerifyConfigured() {
  return Boolean(accountSid() && authToken() && serviceSid());
}

export async function twilioVerifyRequest(path: "Verifications" | "VerificationCheck", values: Record<string, string>) {
  const sid = accountSid();
  const token = authToken();
  const service = serviceSid();
  if (!sid || !token || !service) throw new Error("SMS OTP is not configured. Add Twilio Verify credentials on the server first.");
  const body = new URLSearchParams(values);
  const response = await fetch(`https://verify.twilio.com/v2/Services/${service}/${path}`, {
    method: "POST",
    headers: {
      Authorization: `Basic ${Buffer.from(`${sid}:${token}`).toString("base64")}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body,
    cache: "no-store",
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = typeof data?.message === "string" ? data.message : "SMS provider could not complete OTP verification.";
    throw new Error(message);
  }
  return data as { status?: string; sid?: string; to?: string; channel?: string };
}
