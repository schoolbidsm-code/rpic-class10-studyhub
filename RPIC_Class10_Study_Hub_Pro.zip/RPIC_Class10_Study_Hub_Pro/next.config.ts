import type { NextConfig } from "next";
const nextConfig: NextConfig = {
  images: { remotePatterns: [{ protocol: "https", hostname: "i.postimg.cc" }] },
  poweredByHeader: false
};
export default nextConfig;