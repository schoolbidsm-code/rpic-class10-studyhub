import { PrismaClient, Role } from "@prisma/client";
import bcrypt from "bcryptjs";
const prisma = new PrismaClient();
async function main() {
  const subjects = [
    ["Hindi","book-open"],["English","languages"],["Mathematics","calculator"],
    ["Science","atom"],["Social Science","globe"],["Computer","monitor"]
  ];
  for (let i=0;i<subjects.length;i++) {
    await prisma.subject.upsert({where:{name:subjects[i][0]},update:{sortOrder:i,icon:subjects[i][1]},create:{name:subjects[i][0],sortOrder:i,icon:subjects[i][1]}});
  }
  const email = process.env.INITIAL_ADMIN_EMAIL;
  const password = process.env.INITIAL_ADMIN_PASSWORD;
  if (email && password && password !== "change-this-before-deploy") {
    const passwordHash = await bcrypt.hash(password, 12);
    await prisma.user.upsert({
      where:{email},
      update:{role:Role.ADMIN},
      create:{name:"RPIC Administrator",email,passwordHash,role:Role.ADMIN}
    });
    console.log("Initial admin account ensured.");
  } else {
    console.log("No admin created: configure INITIAL_ADMIN_EMAIL and a strong INITIAL_ADMIN_PASSWORD first.");
  }
}
main().finally(()=>prisma.$disconnect());